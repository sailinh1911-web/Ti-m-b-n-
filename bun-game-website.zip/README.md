# 🍜 Quán Bún - Mini Game

Website game bán bún chạy hoàn toàn bằng HTML, CSS và JavaScript.

## Chạy trên máy

Chỉ cần mở `index.html` bằng trình duyệt.

## Đưa lên GitHub Pages

1. Tạo một repository mới trên GitHub.
2. Upload `index.html`, `style.css`, `script.js`.
3. Vào **Settings → Pages**.
4. Chọn **Deploy from a branch**.
5. Chọn branch `main` và thư mục `/root`.
6. Save.

## Đưa lên Vercel

1. Tạo repository GitHub và upload 3 file.
2. Vào Vercel và import repository.
3. Framework: **Other** hoặc để Vercel tự nhận.
4. Build command để trống.
5. Deploy.

## Tính năng

- Khách hàng ngẫu nhiên
- 6 loại đơn bún
- 8 nguyên liệu
- Đồng hồ thời gian
- Tiền và điểm
- Nâng cấp quán
- Thành tích
- Lưu tiến trình bằng localStorage
- Responsive cho điện thoại

Không cần backend hoặc API.
