(() => {
  "use strict";

  const $ = (selector) => document.querySelector(selector);
  const moneyEl = $("#money");
  const scoreEl = $("#score");
  const servedEl = $("#served");
  const levelEl = $("#level");
  const upgradeLevelEl = $("#upgradeLevel");
  const upgradeCostEl = $("#upgradeCost");
  const upgradeBtn = $("#upgrade");
  const customerEl = $("#customer");
  const speechEl = $("#speech");
  const orderEl = $("#order");
  const selectedListEl = $("#selectedList");
  const timeBar = $("#timeBar");
  const messageEl = $("#message");
  const toastEl = $("#toast");
  const newCustomerBtn = $("#newCustomer");
  const serveBtn = $("#serve");
  const clearBtn = $("#clear");
  const resetBtn = $("#reset");

  const customers = ["🧑", "👩", "👨", "👵", "👴", "🧑‍🎓", "👩‍🎓"];
  const recipes = [
    ["bún", "nước dùng", "thịt bò", "rau"],
    ["bún", "nước dùng", "thịt heo", "rau"],
    ["bún", "nước dùng", "thịt bò", "trứng"],
    ["bún", "nước dùng", "thịt heo", "trứng", "rau"],
    ["bún", "nước dùng", "chả cá", "rau"],
    ["bún", "nước dùng", "đậu phụ", "rau"]
  ];

  const icons = {
    "bún": "🍜",
    "nước dùng": "🥣",
    "thịt bò": "🥩",
    "thịt heo": "🍖",
    "rau": "🥬",
    "trứng": "🥚",
    "chả cá": "🐟",
    "đậu phụ": "🧈"
  };

  const defaultState = {
    money: 50,
    score: 0,
    served: 0,
    level: 1
  };

  let state = loadState();
  let currentOrder = null;
  let selected = [];
  let active = false;
  let timeLeft = 100;
  let timerId = null;
  let toastTimer = null;

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem("bunGameState"));
      if (!saved) return {...defaultState};
      return {
        money: Number.isFinite(saved.money) ? Math.max(0, saved.money) : 50,
        score: Number.isFinite(saved.score) ? Math.max(0, saved.score) : 0,
        served: Number.isFinite(saved.served) ? Math.max(0, saved.served) : 0,
        level: Number.isFinite(saved.level) ? Math.max(1, saved.level) : 1
      };
    } catch {
      return {...defaultState};
    }
  }

  function saveState() {
    try {
      localStorage.setItem("bunGameState", JSON.stringify(state));
    } catch {
      // Game still works if browser storage is unavailable.
    }
  }

  function upgradeCost() {
    return 80 + (state.level - 1) * 60;
  }

  function renderStats() {
    moneyEl.textContent = state.money;
    scoreEl.textContent = state.score;
    servedEl.textContent = state.served;
    levelEl.textContent = state.level;
    upgradeLevelEl.textContent = state.level;
    upgradeCostEl.textContent = upgradeCost();
    upgradeBtn.disabled = state.money < upgradeCost();
    updateAchievements();
  }

  function renderTimer() {
    timeBar.style.width = `${Math.max(0, Math.min(100, timeLeft))}%`;
    if (timeLeft <= 25) {
      timeBar.style.background = "#dc2626";
    } else if (timeLeft <= 50) {
      timeBar.style.background = "#f59e0b";
    } else {
      timeBar.style.background = "var(--orange)";
    }
  }

  function renderSelected() {
    if (!selected.length) {
      selectedListEl.textContent = "Chưa chọn nguyên liệu";
      return;
    }

    selectedListEl.innerHTML = selected.map(name =>
      `<span class="selected-item">${icons[name]} ${name}</span>`
    ).join("");
  }

  function renderOrder() {
    if (!currentOrder) {
      orderEl.className = "order-empty";
      orderEl.textContent = "Chưa có đơn hàng";
      return;
    }

    orderEl.className = "order-list";
    orderEl.innerHTML = currentOrder.map(name =>
      `<span class="order-item">${icons[name]} ${name}</span>`
    ).join("");
  }

  function updateAchievements() {
    $("#a1").classList.toggle("done", state.served >= 5);
    $("#a2").classList.toggle("done", state.money >= 300);
    $("#a3").classList.toggle("done", state.score >= 100);
  }

  function setMessage(text) {
    messageEl.textContent = text;
  }

  function toast(text) {
    toastEl.textContent = text;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("show"), 1800);
  }

  function clearSelection() {
    selected = [];
    document.querySelectorAll(".ingredient").forEach(btn => {
      btn.classList.remove("selected");
      btn.setAttribute("aria-pressed", "false");
    });
    renderSelected();
  }

  function chooseRandomOrder() {
    const recipe = recipes[Math.floor(Math.random() * recipes.length)];
    return [...recipe];
  }

  function startCustomer() {
    clearInterval(timerId);
    currentOrder = chooseRandomOrder();
    selected = [];
    active = true;
    timeLeft = 100;

    customerEl.textContent = customers[Math.floor(Math.random() * customers.length)];
    speechEl.textContent = "Cho mình một tô bún như đơn này nhé!";
    newCustomerBtn.disabled = false;
    serveBtn.disabled = false;

    clearSelection();
    renderOrder();
    renderTimer();
    setMessage("Nhanh tay chọn đủ nguyên liệu rồi phục vụ khách!");
    toast("👤 Khách mới đã đến!");

    const tick = () => {
      const speed = Math.max(1.45, 2.05 - (state.level - 1) * 0.1);
      timeLeft -= speed;

      if (timeLeft <= 0) {
        timeLeft = 0;
        active = false;
        clearInterval(timerId);
        customerEl.textContent = "😢";
        speechEl.textContent = "Mình chờ lâu quá, hẹn lần sau nhé!";
        setMessage("Khách đã rời đi. Bấm “Khách mới” để thử lại.");
        renderTimer();
      } else {
        renderTimer();
      }
    };

    timerId = setInterval(tick, 180);
  }

  function normalize(arr) {
    return [...arr].sort();
  }

  function isExactMatch() {
    if (!currentOrder || selected.length !== currentOrder.length) return false;
    return JSON.stringify(normalize(selected)) === JSON.stringify(normalize(currentOrder));
  }

  function serveCustomer() {
    if (!active || !currentOrder) {
      setMessage("Hãy bấm “Khách mới” trước.");
      toast("👤 Chưa có khách!");
      return;
    }

    clearInterval(timerId);
    active = false;

    if (isExactMatch()) {
      const speedBonus = Math.round(timeLeft / 10);
      const earned = 12 + currentOrder.length * 5 + state.level * 3 + speedBonus;
      const points = 10 + currentOrder.length * 2 + Math.floor(timeLeft / 20);

      state.money += earned;
      state.score += points;
      state.served += 1;

      customerEl.textContent = "😋";
      speechEl.textContent = "Ngon quá! Cảm ơn bạn!";
      setMessage(`Phục vụ chính xác! +${earned}k và +${points} điểm.`);
      toast(`💰 +${earned}k  ⭐ +${points}`);
      saveState();
      renderStats();
    } else {
      state.money = Math.max(0, state.money - 5);
      customerEl.textContent = "😕";
      speechEl.textContent = "Hình như tô bún chưa đúng món...";
      setMessage("Sai nguyên liệu hoặc thiếu nguyên liệu. Bạn mất 5k.");
      toast("😕 Sai đơn hàng -5k");
      saveState();
      renderStats();

      const panel = document.querySelector(".kitchen-panel");
      panel.classList.remove("shake");
      void panel.offsetWidth;
      panel.classList.add("shake");
    }
  }

  function upgradeShop() {
    const cost = upgradeCost();

    if (state.money < cost) {
      toast("💸 Chưa đủ tiền nâng cấp!");
      return;
    }

    state.money -= cost;
    state.level += 1;
    saveState();
    renderStats();
    setMessage(`🎉 Quán đã lên cấp ${state.level}! Khách kiên nhẫn hơn và tiền thưởng tăng.`);
    toast(`🏪 Nâng cấp thành công!`);
  }

  function resetGame() {
    if (!confirm("Bạn có chắc muốn xóa toàn bộ tiến trình và chơi lại từ đầu?")) return;

    clearInterval(timerId);
    state = {...defaultState};
    currentOrder = null;
    selected = [];
    active = false;
    timeLeft = 100;

    saveState();
    renderStats();
    renderOrder();
    clearSelection();
    renderTimer();

    customerEl.textContent = "🧑";
    speechEl.textContent = "Bấm “Khách mới” để bắt đầu!";
    setMessage("Đã bắt đầu lại từ đầu.");
    toast("🔄 Đã reset game");
  }

  document.querySelectorAll(".ingredient").forEach(button => {
    button.setAttribute("aria-pressed", "false");

    button.addEventListener("click", () => {
      if (!active) {
        toast("👤 Hãy gọi khách trước!");
        return;
      }

      const name = button.dataset.name;

      if (selected.includes(name)) {
        selected = selected.filter(item => item !== name);
        button.classList.remove("selected");
        button.setAttribute("aria-pressed", "false");
      } else {
        selected.push(name);
        button.classList.add("selected");
        button.setAttribute("aria-pressed", "true");
      }

      renderSelected();
    });
  });

  newCustomerBtn.addEventListener("click", startCustomer);
  serveBtn.addEventListener("click", serveCustomer);
  clearBtn.addEventListener("click", () => {
    if (!active) {
      toast("👤 Chưa có khách!");
      return;
    }
    clearSelection();
    toast("🗑 Đã xóa tô bún");
  });
  upgradeBtn.addEventListener("click", upgradeShop);
  resetBtn.addEventListener("click", resetGame);

  renderStats();
  renderOrder();
  renderSelected();
  renderTimer();
})();
